<script setup>

</script>

<template>
<div class="fixed flex items-center justify-center w-24 h-16 bg-gray-100 border-2 border-gray-400 bottom-4 left-4 rounded-xl">
      <span class="sm:hidden">Mobile</span>
      <span class="hidden sm:block md:hidden">SM</span>
      <span class="hidden md:block lg:hidden">MD</span>
      <span class="hidden lg:block xl:hidden">LG</span>
      <span class="hidden xl:block 2xl:hidden">XL</span>
      <span class="hidden 2xl:block">2XL</span>
    </div>
</template>

<style scoped>

</style>